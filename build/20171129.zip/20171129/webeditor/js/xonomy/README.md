# Xonomy

<img src="http://www.lexiconista.com/Xonomy/xonomy3.gif" style="display: block; width: 100%; max-width: 948px; border: 2px solid #333333"/>

Xonomy is a web-based, schema-driven XML editor. For demos and documentation see http://www.lexiconista.com/xonomy/
