1. Unpack this archive
2. Copy all files in one folder on the box
3. Run "bash setup-cb16.sh"
4. Add line to nginx.conf as described in console output of step 3
